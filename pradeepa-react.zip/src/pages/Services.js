import React from 'react';
import InnerServices from './InnerServices';


export default function Services() {
    return (
        <>
            <h2>Service Page: </h2>
            <InnerServices />
        </>
    )
}
